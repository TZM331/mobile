package com.example.myimageapp

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.graphics.Bitmap
import android.graphics.Canvas
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.graphics.Paint
import android.widget.TextView
class MainActivity : AppCompatActivity() {

    private lateinit var takePictureLauncher: ActivityResultLauncher<Intent>
    private lateinit var captureBtn: Button
    private lateinit var saveBtn: Button
    private lateinit var emojiBtn: Button
    private lateinit var capturedImage: ImageView
    private lateinit var clothOverlay: ImageView
    private lateinit var imageContainer: FrameLayout

    private var currentPhotoPath: String = ""



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val longSleeveText: TextView = findViewById(R.id.longSleeveText)
        longSleeveText.paintFlags = longSleeveText.paintFlags or Paint.UNDERLINE_TEXT_FLAG


        // adjust for system bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // init views
        captureBtn = findViewById(R.id.captureBtn)
        saveBtn = findViewById(R.id.saveBtn)
        emojiBtn = findViewById(R.id.emojiBtn)
        capturedImage = findViewById(R.id.capturedImage)
        clothOverlay = findViewById(R.id.clothOverlay)
        imageContainer = findViewById(R.id.imageContainer)

        // register ActivityResult launcher
        takePictureLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK) {
                val file = File(currentPhotoPath)
                val photoURI: Uri = FileProvider.getUriForFile(
                    this,
                    "${applicationContext.packageName}.provider",
                    file
                )
                capturedImage.setImageURI(photoURI)
                clothOverlay.visibility = View.VISIBLE
            } else {
                Toast.makeText(this, "Capture cancelled", Toast.LENGTH_SHORT).show()
            }
        }

        // capture button
        captureBtn.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.CAMERA), 1000)
            } else {
                openCamera()
            }
        }

        // save button
        saveBtn.setOnClickListener {
            saveImageWithOverlay()
        }

        // emoji button
        emojiBtn.setOnClickListener {
            showEmojiPicker()
        }
    }

    // permission callback
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1000 && grantResults.isNotEmpty()
            && grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            openCamera()
        } else {
            Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)

        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "PHOTO_$timeStamp.jpg"

        val storageDir = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "niabsen")
        if (!storageDir.exists()) storageDir.mkdirs()
        val photoFile = File(storageDir, fileName)
        currentPhotoPath = photoFile.absolutePath

        val photoURI: Uri = FileProvider.getUriForFile(
            this,
            "${applicationContext.packageName}.provider",
            photoFile
        )

        intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)

        takePictureLauncher.launch(intent)
    }

    private fun showEmojiPicker() {
        val emojis = arrayOf("😎", "😂", "😍", "🤔", "🔥", "❤️", "🌟")
        val builder = androidx.appcompat.app.AlertDialog.Builder(this)
        builder.setTitle("Choose an Emoji")
        builder.setItems(emojis) { dialog, which ->
            addEmoji(emojis[which])
            dialog.dismiss()
        }
        builder.show()
    }

    private fun addEmoji(emoji: String) {
        val emojiView = AppCompatTextView(this).apply {
            text = emoji
            textSize = 48f
            setPadding(8, 8, 8, 8)
            setOnTouchListener(DragTouchListener())
        }

        val lp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        )
        lp.leftMargin = 50
        lp.topMargin = 50

        imageContainer.addView(emojiView, lp)
    }

    inner class DragTouchListener : View.OnTouchListener {
        private var lastX = 0f
        private var lastY = 0f

        override fun onTouch(view: View, event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = event.rawX
                    lastY = event.rawY
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - lastX
                    val dy = event.rawY - lastY
                    view.x = view.x + dx
                    view.y = view.y + dy
                    lastX = event.rawX
                    lastY = event.rawY
                    return true
                }
            }
            return false
        }
    }

    private fun saveImageWithOverlay() {
        if (capturedImage.drawable == null) {
            Toast.makeText(this, "No image to save", Toast.LENGTH_SHORT).show()
            return
        }

        val bitmap = Bitmap.createBitmap(
            capturedImage.width,
            capturedImage.height,
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bitmap)
        capturedImage.draw(canvas)
        clothOverlay.draw(canvas)

        // draw emojis
        // draw emojis properly
        for (i in 0 until imageContainer.childCount) {
            val child = imageContainer.getChildAt(i)
            if (child is AppCompatTextView) {
                canvas.save()
                // translate canvas to the child's current position
                val left = child.x - capturedImage.x
                val top = child.y - capturedImage.y
                canvas.translate(left, top)
                child.draw(canvas)
                canvas.restore()
            }
        }


        try {
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val fileName = "FINAL_$timeStamp.jpg"

            val fos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/MyApp")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                contentResolver.openOutputStream(uri!!)
            } else {
                val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val file = File(picturesDir, fileName)
                FileOutputStream(file)
            }

            fos?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
            }

            Toast.makeText(this, "Saved to Gallery", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show()
        }
    }
}
